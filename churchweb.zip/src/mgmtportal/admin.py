from django.contrib import admin
from .models import Members, MFinance

# Register your models here.
admin.site.register(Members)
admin.site.register(MFinance)
