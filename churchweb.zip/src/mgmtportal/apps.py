from django.apps import AppConfig


class MgmtportalConfig(AppConfig):
    name = 'mgmtportal'
