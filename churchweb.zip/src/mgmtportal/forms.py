from django import forms
from .models import Members, MFinance


class MemberForm(forms.ModelForm):
    genderchoice = (
        ('M', 'Male'),
        ('F', 'Female'),
        ('O', 'Other'),
    )
    gender = forms.ChoiceField(widget=forms.RadioSelect, choices=genderchoice)

    class Meta:
        model = Members
        fields = "__all__"
        widgets = {
            'dateofbirth': forms.DateInput(attrs={'class': 'datepicker', 'type': 'date'}),
            'joined': forms.DateInput(attrs={'class': 'datepicker', 'type': 'date'}),
        }


class MFinanceForm(forms.ModelForm):
    class Meta:
        model = MFinance
        fields = "__all__"
        widgets = {
            'pledge1date': forms.DateInput(attrs={'class': 'datepicker'}),
            'pledge2date': forms.DateInput(attrs={'class': 'datepicker'}),
        }
