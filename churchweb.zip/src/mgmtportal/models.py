from django.db import models
from django.contrib.auth import get_user_model

MyUser = get_user_model()


# Create your models here.
class Members(models.Model):
    ministrychoice = (
        ('Praise and Worship', 'Praise and Worship'),
        ('Technical', 'Technical'),
        ('Ushering', 'Ushering'),
        ('ICT and Media', 'ICT and Media'),
        ('Women', 'Women'),
        ('Men', 'Men'),
        ('Youth', 'Youth'),
    )
    genderchoice = (
        ('M', 'Male'),
        ('F', 'Female'),
        ('O', 'Other'),
    )
    maritalchoice = (
        ('Single', 'Single'),
        ('Married', 'Married'),
    )
    memberid = models.OneToOneField(MyUser, on_delete=models.CASCADE, primary_key=True)
    surname = models.CharField(max_length=30, null=False, blank=False)
    othernames = models.CharField(max_length=60, null=False, blank=False)
    email = models.EmailField(null=True, blank=True, unique=True)
    phone = models.CharField(max_length=13, null=True, blank=True, unique=True)
    gender = models.CharField(max_length=1, choices=genderchoice)
    dateofbirth = models.DateField()
    is_leader = models.BooleanField(default=False)
    is_admin = models.BooleanField(default=False)
    ministry = models.CharField(max_length=255, choices=ministrychoice)
    maritalstatus = models.CharField(max_length=255, choices=maritalchoice)
    joined = models.DateField()


class MFinance(models.Model):
    memberid = models.OneToOneField(MyUser, on_delete=models.CASCADE, primary_key=True)
    tithe = models.DecimalField(max_digits=65, decimal_places=2)
    tithingdate = models.DateField()
    pledge1 = models.DecimalField(max_digits=65, decimal_places=2)
    pedge1date = models.DateField()
    pledge2 = models.DecimalField(max_digits=65, decimal_places=2)
    pledge2date = models.DateField()
