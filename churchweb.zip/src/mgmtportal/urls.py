from django.urls import path
from . import views

urlpatterns = [
    path('adduser/', views.adduser_view, name='add'),
    path('show/', views.show_view, name='show'),
    # path('logout/', views.logout_view, name='logout'),
]
