from django.shortcuts import render, HttpResponseRedirect
from .models import Members, MFinance, MyUser
from .forms import MemberForm, MFinanceForm
from django.contrib.auth.decorators import login_required


# Create your views here.
@login_required
def show_view(request):
    members = Members.objects.all()
    context = {
        'members': members
    }
    return render(request, "show.html", context)

"""@login_required
def adduser_view(request, *args, **kwargs):
    try:
        m = Members.objects.get(memberid=request.user.id)
        form = MemberForm(request.POST or None, instance=m)
        if Members.objects.get(memberid=request.user.id):
            m = Members.objects.get(memberid=request.user.id)
            if m.memberid_id == request.user.id:
                if request.method == "POST":
                    if form.is_valid():
                        if request.POST['memberid'] == request.user.id:
                            form.save()
                            return HttpResponseRedirect('/portal/show')
                        membererr = "You can only register your own profile. Please select ***" + str(
                            request.user.username) + "*** and submit to continue"
                        context = {
                            'form': form,
                            'membererr': membererr
                        }
                        return render(request, "adduser.html", context)
                msg = "Your profile had been saved. Edit to make changes."

                context = {
                    'msg': msg,
                    'form': form
                }
                return render(request, "adduser.html", context)
    except:
        form = MemberForm(request.POST or None)
        if request.method == "POST":
            if form.is_valid():
                if request.POST['memberid'] == request.user.id:
                    form.save()
                    return HttpResponseRedirect('/portal/show')
                membererr = "You can only register your own profile. Please select ***" + str(request.user.username) + "*** and submit to continue"
                context = {
                    'form': form,
                    'membererr': membererr
                }
                return render(request, "adduser.html", context)
        return render(request, "adduser.html", {'form': form})"""

@login_required
def adduser_view(request):
    msg = ""
    try:
        m = Members.objects.get(memberid=request.user.id)
        form = MemberForm(request.POST or None, instance=m)
        if Members.objects.get(memberid=request.user.id):
            m = Members.objects.get(memberid=request.user.id)
            if m.memberid_id == request.user.id:
                form = MemberForm(request.POST or None, instance=m)
                msg = "Your profile had been saved. Edit to make changes."
    except Members.DoesNotExist:
        form = MemberForm(request.POST or None)

    if request.method == "POST":
        print(request.POST['memberid'])
        print(request.user.id)
        if str(request.POST['memberid']) == str(request.user.id):
            if form.is_valid():
                form.save()
                return HttpResponseRedirect('/portal/show')
        membererr = "You can only register your own profile. Please select ***" + str(request.user.username) + "*** and submit to continue"
        context = {
            'form': form,
            'membererr': membererr
        }
        return render(request, "adduser.html", context)
    context = {
        'form': form,
        'msg': msg
    }
    return render(request, "adduser.html", context)


