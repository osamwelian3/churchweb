from django.apps import AppConfig


class UseraccountsConfig(AppConfig):
    name = 'useraccounts'
