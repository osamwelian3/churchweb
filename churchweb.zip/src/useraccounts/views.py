from django.shortcuts import render, redirect
from .forms import UserCreationForm, UserLoginForm
from django.http import HttpResponseRedirect
from django.contrib.auth import login, logout, authenticate, get_user_model, decorators
from django.template import RequestContext

# Create your views here.

User = get_user_model()


def register(request, *args, **kwargs):
    if request.user.is_authenticated:
        return redirect('/')
    next = request.GET.get('next')
    form = UserCreationForm(request.POST or None)
    if form.is_valid():
        password1 = form.cleaned_data.get('password1')
        password2 = form.cleaned_data.get('password2')
        if password1 and password2 and password1 != password2:
            pwderror = "Passwords do not match"
            context = {
                'form': form,
                'pwderror': pwderror
            }
            return render(request, "register.html", context)

        form.save()
        if next:
            return redirect(next)
        return HttpResponseRedirect('/login')
    context = {
        'form': form,
        'next': next
    }
    return render(request, "register.html", context)


"""def login_view(request, *args, **kwargs):
    form = UserLoginForm()
    if request.method == "POST":
        pass
    else:
        return render(request, 'login.html', {'form': form})"""


def login_view(request):
    if request.user.is_authenticated:
        return redirect('/')
    next = request.GET.get('next')
    if request.user.is_authenticated:
        return HttpResponseRedirect('/')
    form = UserLoginForm(request.POST or None)
    if form.is_valid():
        # password = form.cleaned_data.get('password')
        # user = authenticate(username=username, password=password)
        user = form.cleaned_data.get('user_obj')
        # print(user_obj)
        login(request, user)
        if next:
            return redirect(next)
        return HttpResponseRedirect('/')
    context = {
        'form': form,
        'next': next,
    }
    return render(request, "login.html", context)


def logout_view(request):
    logout(request)
    return HttpResponseRedirect('/login')


